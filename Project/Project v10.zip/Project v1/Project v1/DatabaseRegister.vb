﻿Public Class DatabaseRegister

    Private Sub LoginsBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles LoginsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.LoginsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Login_Database_V1DataSet)

    End Sub

    Private Sub DatabaseRegister_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Login_Database_V1DataSet.Logins' table. You can move, or remove it, as needed.
        Me.LoginsTableAdapter.Fill(Me.Login_Database_V1DataSet.Logins)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Me.Validate()
            Me.LoginsBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.Login_Database_V1DataSet)
            LoginsBindingSource.AddNew()

        Catch ex As Exception
            MessageBox.Show("test")

        End Try
    End Sub
End Class