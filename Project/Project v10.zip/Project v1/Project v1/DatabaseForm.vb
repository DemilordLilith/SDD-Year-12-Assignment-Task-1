﻿Public Class DatabaseForm

    Private Sub LoginsBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles LoginsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.LoginsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Login_Database_V1DataSet)

    End Sub

    Private Sub DatabaseForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Login_Database_V1DataSet.Logins' table. You can move, or remove it, as needed.
        Me.LoginsTableAdapter.Fill(Me.Login_Database_V1DataSet.Logins)

    End Sub
End Class