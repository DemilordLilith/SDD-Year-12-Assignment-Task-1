﻿Public Class NewUser
    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        Me.Close()
        Splash.Close()
        Generator.Close()
        Help.Close()
        Login.Close()
        Student.Close()
    End Sub
    'saves the userrname as the name for the text file and put the password inside the text file'

End Class