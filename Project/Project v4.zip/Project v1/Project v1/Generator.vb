﻿Public Class Generator

    Private Sub Generator_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
        Student.Close()
        Splash.Close()
        Login.Close()
    End Sub
    Private Sub HomePageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomePageToolStripMenuItem.Click
        Me.Hide()
        Splash.Show()
    End Sub

    Private Sub StudentPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentPageToolStripMenuItem.Click
        Me.Hide()
        Student.Show()
    End Sub

    Private Sub TeacherPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TeacherPageToolStripMenuItem.Click
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub HelpPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpPageToolStripMenuItem.Click
        Help.Show()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Help.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
        Student.Close()
        Splash.Close()
    End Sub

    Private Sub LoadToolStripMenuItem_Click(sender As Object, e As EventArgs)
        'Not Done'
    End Sub

    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click
        'Not Done'
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click
        'Not Done'
    End Sub

    Private Sub SaveFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveFileToolStripMenuItem.Click
        'Not Done'
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        'Not Done'
        'Browse for a text file and read it into the textbox'

    End Sub

End Class