﻿Public Class Help
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Generator.CloseMe()
    End Sub
End Class