﻿Public Class Generator

    Private Sub Generator_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CloseMe()
    End Sub
    Private Sub HomePageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomePageToolStripMenuItem.Click
        Me.Hide()
        Splash.Show()
    End Sub

    Private Sub StudentPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentPageToolStripMenuItem.Click
        Me.Hide()
        Student.Show()
    End Sub

    Private Sub TeacherPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TeacherPageToolStripMenuItem.Click
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub HelpPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpPageToolStripMenuItem.Click
        Help.Show()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Help.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
        Student.Close()
        Splash.Close()
    End Sub

    Private Sub LoadToolStripMenuItem_Click(sender As Object, e As EventArgs)
        'Not Done'
    End Sub

    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click
        'Not Done'
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click
        SaveFile()
    End Sub

    Private Sub SaveFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveFileToolStripMenuItem.Click
        InstantSaveFile()
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        OpenFile()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub




    'Modules VVVVVVV



    Public Sub SaveFile()
        'Generator.SaveFile
        'https://msdn.microsoft.com/en-us/library/e4a710b1(v=vs.110).aspx?cs-save-lang=1&cs-lang=vb#code-snippet-1
        ' Create a SaveFileDialog to request a path and file name to save to.
        Dim saveFile1 As New SaveFileDialog()

        ' Initialize the SaveFileDialog to specify the RTF extension for the file.
        saveFile1.DefaultExt = ".rtf" '"*.rtf" (ritch text file)

        'defines the unicode varient
        saveFile1.Filter = "RTF Files|*.rtf"

        ' Determine if the user selected a file name from the saveFileDialog. (not 100% sure what this means )
        If (saveFile1.ShowDialog() = System.Windows.Forms.DialogResult.OK) _
            And (saveFile1.FileName.Length) > 0 Then

            'Save the Ritch text box into a file
            RichTextBox1.SaveFile(saveFile1.FileName,
                RichTextBoxStreamType.PlainText)
        End If
    End Sub

    Public Sub OpenFile()
        'Generator.OpenFile
        If (OpenFileDialog1.ShowDialog = DialogResult.OK) Then 'opens file
            RichTextBox1.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog1.FileName) 'reads content of file into the textbox
        End If
    End Sub

    Public Sub InstantSaveFile()
        'Generator.InstantSaveFile
        Dim writer As System.IO.TextWriter = New System.IO.StreamWriter("C:\Users\Chali\Documents\GitHub\SDD-Year-12-Assignment-Task-1\Project\Project v1\SaveFile.text") 'Locates directory to make a "SaveFile.text"
        writer.Write(RichTextBox1.Text) 'writes to the file
        writer.Close() 'closes the file
    End Sub

    Public Sub CloseMe()
        'Generator.CloseMe
        End
    End Sub

End Class