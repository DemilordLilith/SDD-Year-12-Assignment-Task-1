﻿Public Class Prnform
    Dim count As Integer = 1
    Private Sub Prnform_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        count -= 1
        If count = 0 Then
            PrintForm1.Print()
            Timer1.Stop()
        End If

    End Sub
End Class