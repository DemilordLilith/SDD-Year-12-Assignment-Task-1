﻿Imports System
Imports System.IO
Public Class Student
    Dim removedWords(0) As String
    Private Sub OpenListToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenListToolStripMenuItem.Click
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim lines = File.ReadAllLines(OpenFileDialog1.FileName)
            ListBox1.Items.Clear()
            ListBox1.Items.AddRange(lines)
        End If
    End Sub

    Private Sub OpenPassageToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles OpenPassageToolStripMenuItem.Click
        If (OpenFileDialog1.ShowDialog = DialogResult.OK) Then 'opens file
            RichTextBox1.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog1.FileName) 'reads content of file into the textbox
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click
        PrintForm1.Print()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Help.Show()
    End Sub

    Private Sub HelpPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpPageToolStripMenuItem.Click
        Help.Show()
    End Sub

    Private Sub TeacherPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TeacherPageToolStripMenuItem.Click
        Me.Hide()
        Login.Show()

    End Sub

    Private Sub HomePageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomePageToolStripMenuItem.Click
        Me.Hide()
        Splash.Show()
    End Sub
End Class