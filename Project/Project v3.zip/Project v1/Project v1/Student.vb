﻿Public Class Student

    Private Sub Student_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Generator.Close()
        Help.Show()
        Me.Close()
        Splash.Close()
        Login.Close()
    End Sub


    Private Sub HomePageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomePageToolStripMenuItem.Click
        Me.Hide()
        Splash.Show()
    End Sub

    Private Sub StudentPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentPageToolStripMenuItem.Click
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub TeacherPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TeacherPageToolStripMenuItem.Click
        Me.Hide()
        Generator.Show()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Help.Show()
    End Sub
End Class