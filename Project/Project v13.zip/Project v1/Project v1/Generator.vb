﻿Public Class Generator

    Private Sub Generator_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CloseMe()
    End Sub
    Private Sub HomePageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomePageToolStripMenuItem.Click
        Me.Hide()
        Splash.Show()
    End Sub

    Private Sub StudentPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentPageToolStripMenuItem.Click
        Me.Hide()
        Student.Show()
    End Sub

    Private Sub TeacherPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TeacherPageToolStripMenuItem.Click
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub HelpPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpPageToolStripMenuItem.Click
        Help.Show()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Help.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
        Student.Close()
        Splash.Close()
    End Sub

    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click 'printing
        PrintForm1.Print()
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click 'save as
        SaveFile()
    End Sub

    Private Sub SaveFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveFileToolStripMenuItem.Click 'instant save
        InstantSaveFile()
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click 'open file
        OpenFile()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked 'lol wut idk 

    End Sub
    Private Sub LoadToolStripMenuItem_Click(sender As Object, e As EventArgs) 'loading

    End Sub

    'Modules VVVVVVV

    Public Sub SaveFile()
        'Generator.SaveFile
        'https://msdn.microsoft.com/en-us/library/e4a710b1(v=vs.110).aspx?cs-save-lang=1&cs-lang=vb#code-snippet-1
        ' Create a SaveFileDialog to request a path and file name to save to.
        Dim saver As New SaveFileDialog()

        ' Initialize the SaveFileDialog to specify the RTF extension for the file
         saver.DefaultExt = ".rtf" '"*.rtf" (ritch text file)

        'defines the unicode varient
        saver.Filter = "RTF Files|*.rtf"

        ' Determine if the user selected a file name from the saveFileDialog. Checkes if you have typed in a file name and clicke dok otherwise they cant save it 
        If (saver.ShowDialog() = System.Windows.Forms.DialogResult.OK) _
            And (saver.FileName.Length) > 0 Then

            'Save the Ritch text box into a file
            RichTextBox1.SaveFile(saver.FileName,
                RichTextBoxStreamType.PlainText)
        End If
    End Sub

    Public Sub OpenFile()
        'Generator.OpenFile
        If (OpenFileDialog1.ShowDialog = DialogResult.OK) Then 'opens file
            RichTextBox1.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog1.FileName) 'reads content of file into the textbox
        End If
    End Sub

    Public Sub InstantSaveFile()
        'Generator.InstantSaveFile
        Dim writer As System.IO.TextWriter = New System.IO.StreamWriter("C:\Users\Chali\Documents\GitHub\SDD-Year-12-Assignment-Task-1\Project\Project v1\SaveFile.text") 'Locates directory to make a "SaveFile.text"
        writer.Write(RichTextBox1.Text) 'writes to the file
        writer.Close() 'closes the file
    End Sub

    Public Sub CloseMe()
        'Generator.CloseMe
        End
    End Sub

    Public Sub Generate()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        RichTextBox1.Text = Trim(RichTextBox1.Text)
        RichTextBox1.AppendText("")

        Dim totalword As Integer = UBound(Split(RichTextBox1.Text, ""))
        Dim removedwords() As String
        Dim startpos As Integer = 0
        Dim textlength As Integer = 0
        Dim arraysize As Integer = 0
        Dim count As Integer = NumericUpDown1.Value

        For i = 0 To totalword - 1
            Startpos += 1
            ReDim Preserve removedwords(arraysize)
            While Mid(RichTextBox1.Text, Startpos, 1) <> ""
                Startpos += 1
                textlength += 1
            End While
            count -= 1
            If count = 0 Then
                removedwords(arraysize) = Mid(RichTextBox1.Text, Startpos - textlength, textlength)
                RichTextBox1.Text = Mid(RichTextBox1.Text, 1, Startpos - textlength - 1) & New String("_", textlength) & Mid(RichTextBox1.Text, Startpos, Len(RichTextBox1.Text))

                arraysize += 1
                count = NumericUpDown1.Value
            End If
            textlength = 0
            textlength += 1
        Next

        For i = 0 To arraysize - 1
            ListBox1.Items.Add(removedwords(i))
        Next

        Dim writer As System.IO.TextWriter = New System.IO.StreamWriter("C:\Users\<YourUsername>\Documents")
        Dim options As String
        For i = 0 To removedwords.Length - 1
            options = options & removedwords(i) & ", "
        Next
        writer.Write(options)

        writer.Close()



    End Sub
End Class