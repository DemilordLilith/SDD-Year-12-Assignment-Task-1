﻿Public Class Student

    Private Sub Student_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Generator.Close()

        Me.Close()
        Splash.Close()
    End Sub

    Private Sub FormCloze(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Generator.Close()

        Splash.Close()
    End Sub

    Private Sub HomePageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomePageToolStripMenuItem.Click
        Me.Hide()
        Splash.Show()
    End Sub

    Private Sub StudentPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentPageToolStripMenuItem.Click
        Me.Hide()
        Me.Show()
    End Sub

    Private Sub TeacherPageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TeacherPageToolStripMenuItem.Click
        Me.Hide()
        Generator.Show()
    End Sub




End Class